package main;

public class Main {
	
	public static void main(String[] agrs) {
		new StartMenu();
	}

}
